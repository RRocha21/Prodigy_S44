                           
   
   

"use strict"; 

var MapSpiderGraph = ( function ()
{
	function _Init() 
	{
	}

	return {
		Init 					: _Init
	 };
})();

                                                                                                    
                                           
                                                                                                    
(function()
{
	MapSpiderGraph.Init();
	                                                                   
	                                                                         

})();
