                             
   
   

"use strict"; 

var PlayerStats_Web_Weapons = ( function ()
{
	function _Init() 
	{
	}

	return {
		Init 					: _Init
	 };
})();

                                                                                                    
                                           
                                                                                                    
(function()
{
	PlayerStats_Web_Weapons.Init();
	                                                                            
	                                                                         

})();
