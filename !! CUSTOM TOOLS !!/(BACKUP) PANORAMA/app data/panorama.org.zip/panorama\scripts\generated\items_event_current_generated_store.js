  
                                        
                                                                 
                                                           
                                 
                               
  
                      


  
                                             
  
var g_ActiveTournamentInfo =
{
	eventid: 20,
	organization: 'iem',
	location: 'rio2022',
	stickerid_graffiti: 6085,
	itemid_pass: 4850,
	itemid_coins: [
		4851, 4852, 4853, 4854
	],
	itemid_pack: 4855,
	itemid_charge: 4856,
	num_global_offerings: 2,
	active: false,
};


  
                                                   
  
var g_ActiveTournamentTeams =
[
	       
	{
		teamid: 84,
		team: 'ence',
		stickerid_graffiti: 6061,
		team_group: 'legends',
	},
	            
	{
		teamid: 61,
		team: 'faze',
		stickerid_graffiti: 6062,
		team_group: 'legends',
	},
	         
	{
		teamid: 95,
		team: 'hero',
		stickerid_graffiti: 6063,
		team_group: 'legends',
	},
	                
	{
		teamid: 12,
		team: 'navi',
		stickerid_graffiti: 6064,
		team_group: 'legends',
	},
	                    
	{
		teamid: 1,
		team: 'nip',
		stickerid_graffiti: 6065,
		team_group: 'legends',
	},
	                 
	{
		teamid: 72,
		team: 'spr',
		stickerid_graffiti: 6066,
		team_group: 'legends',
	},
	              
	{
		teamid: 48,
		team: 'liq',
		stickerid_graffiti: 6067,
		team_group: 'legends',
	},
	              
	{
		teamid: 81,
		team: 'spir',
		stickerid_graffiti: 6068,
		team_group: 'legends',
	},
	          
	{
		teamid: 112,
		team: 'nine',
		stickerid_graffiti: 6069,
		team_group: 'challengers',
	},
	                  
	{
		teamid: 114,
		team: 'bne',
		stickerid_graffiti: 6070,
		team_group: 'challengers',
	},
	      
	{
		teamid: 69,
		team: 'big',
		stickerid_graffiti: 6071,
		team_group: 'challengers',
	},
	         
	{
		teamid: 33,
		team: 'c9',
		stickerid_graffiti: 6072,
		team_group: 'challengers',
	},
	                
	{
		teamid: 98,
		team: 'evl',
		stickerid_graffiti: 6073,
		team_group: 'challengers',
	},
	       
	{
		teamid: 106,
		team: 'mouz',
		stickerid_graffiti: 6074,
		team_group: 'challengers',
	},
	     
	{
		teamid: 96,
		team: 'og',
		stickerid_graffiti: 6075,
		team_group: 'challengers',
	},
	           
	{
		teamid: 89,
		team: 'vita',
		stickerid_graffiti: 6076,
		team_group: 'challengers',
	},
	            
	{
		teamid: 116,
		team: 'zzn',
		stickerid_graffiti: 6077,
		team_group: 'contenders',
	},
	         
	{
		teamid: 6,
		team: 'fntc',
		stickerid_graffiti: 6078,
		team_group: 'contenders',
	},
	        
	{
		teamid: 85,
		team: 'furi',
		stickerid_graffiti: 6079,
		team_group: 'contenders',
	},
	              
	{
		teamid: 115,
		team: 'gl',
		stickerid_graffiti: 6080,
		team_group: 'contenders',
	},
	                   
	{
		teamid: 86,
		team: 'gray',
		stickerid_graffiti: 6081,
		team_group: 'contenders',
	},
	              
	{
		teamid: 108,
		team: 'ihc',
		stickerid_graffiti: 6082,
		team_group: 'contenders',
	},
	                   
	{
		teamid: 113,
		team: 'imp',
		stickerid_graffiti: 6083,
		team_group: 'contenders',
	},
	            
	{
		teamid: 109,
		team: 'out',
		stickerid_graffiti: 6084,
		team_group: 'contenders',
	},
];


  
                                                         
  

var g_ActiveTournamentStoreLayout =
[
	[
	g_ActiveTournamentInfo.itemid_pass,
	g_ActiveTournamentInfo.itemid_pack,
	'#CSGO_TournamentPass_rio2022_pack_tinyname'
	],
	[
	4857,                                
	4867,                                  
	'#CSGO_crate_store_pack_rio2022_legends_groupname'
	],
	[
	4858,                                    
	4868,                                      
	'#CSGO_crate_store_pack_rio2022_challengers_groupname'
	],
	[
	4859,                                   
	4869,                                     
	'#CSGO_crate_store_pack_rio2022_contenders_groupname'
	],
	[
	4870,                                    
	'#CSGO_crate_store_pack_rio2022_signatures_groupname'
	],
];

var g_ActiveTournamentPasses =
[
	g_ActiveTournamentInfo.itemid_pass,
	g_ActiveTournamentInfo.itemid_pack,
];


  
                                               
  
